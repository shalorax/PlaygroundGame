extends CharacterBody2D

signal respawned()

const SPEED = 400.0
const JUMP_VELOCITY = -300.0

@onready var animated_sprite = $Character



func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta
		animated_sprite.play("jump_anim")
	
	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
		animated_sprite.flip_h = direction < 0
		if is_on_floor():
			animated_sprite.play("walking")
	else:
		velocity.x = move_toward(velocity.x, 0, 80)
		if is_on_floor():
			animated_sprite.play("Idle")

	move_and_slide()

	
