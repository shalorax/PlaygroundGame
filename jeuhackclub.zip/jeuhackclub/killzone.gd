extends Area2D

@onready var timer = $Timer
@onready var son_fah: AudioStreamPlayer = $"CollisionShape2D/son fah"

func _on_body_entered(body):
	son_fah.play()
	timer.start()

func _on_timer_timeout():
	get_tree().reload_current_scene()
