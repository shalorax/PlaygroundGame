extends CharacterBody2D

@onready var sfxwalk: AudioStreamPlayer = $sfxwalk
@onready var sfxjump: AudioStreamPlayer = $sfxjump
@onready var sprite_2d: AnimatedSprite2D = $Sprite2D

var spawn_point: Vector2

func _ready():
	spawn_point = global_position

const SPEED = 600
const JUMP_VELOCITY = -600


func _physics_process(delta: float) -> void:
	# Add the gravity.
	if not is_on_floor():
		velocity += get_gravity() * delta

	# Handle jump.
	if Input.is_action_just_pressed("jump") and is_on_floor():
		velocity.y = JUMP_VELOCITY
		sfxjump.play()
	
		

	# Get the input direction and handle the movement/deceleration.
	# As good practice, you should replace UI actions with custom gameplay actions.
	var direction := Input.get_axis("left", "right")
	if direction:
		velocity.x = direction * SPEED
		sprite_2d.flip_h = direction < 0
	else:
		velocity.x = move_toward(velocity.x, 0, SPEED)
		sfxwalk.play()

	# Handle animations
	if not is_on_floor():
		sprite_2d.play("jump")
	elif direction:
		sprite_2d.play("walk")
	else:
		sprite_2d.play("idle")

		

	move_and_slide()
	
	


func _on_area_2d_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if body == self: 
		global_position = spawn_point
		velocity = Vector2.ZERO
		
func bounce(force: float) -> void:
	velocity.y = force
		
