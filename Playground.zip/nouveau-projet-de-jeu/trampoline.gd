extends Area2D


# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	pass


func _on_body_entered(p) -> void:
	if p.is_in_group("player"):
		# Only trigger from above
		#if p.global_position.y < global_position.y:
		p.bounce(-800)
			
